'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"version.json": "e4aae346b9d6aa959c707106906620aa",
"index.html": "c53e68eb7da317567b965fd4daab8c31",
"/": "c53e68eb7da317567b965fd4daab8c31",
"main.dart.js": "aecf52b8d78bc1d8260860a56453c13b",
"flutter.js": "c71a09214cb6f5f8996a531350400a9a",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "7f7de762a10a2c6775fe1f60f6d2f0c7",
"assets/AssetManifest.json": "dcce607a98a1da85e85d720bf6058a62",
"assets/NOTICES": "53d15a9ebeeca394f03ba49da29b1def",
"assets/FontManifest.json": "90193e23f7fe587e023faf3d984f334b",
"assets/AssetManifest.bin.json": "9e083b23e6eb942638c186be0c4d9f38",
"assets/packages/line_icons/lib/assets/fonts/LineIcons.ttf": "bcaf3ba974cf7900b3c158ca593f4971",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "89ed8f4e49bcdfc0b5bfc9b24591e347",
"assets/packages/font_awesome_flutter/lib/fonts/fa-solid-900.ttf": "b72c617acdf2227c8b1413215f620711",
"assets/packages/font_awesome_flutter/lib/fonts/fa-regular-400.ttf": "a5d7457fda15b7622c14f432ba63039a",
"assets/packages/font_awesome_flutter/lib/fonts/fa-brands-400.ttf": "f25e8e701660fb45e2a81ff3f43c6d5c",
"assets/packages/rflutter_alert/assets/images/icon_success.png": "8bb472ce3c765f567aa3f28915c1a8f4",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_success.png": "7d6abdd1b85e78df76b2837996749a43",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_error.png": "2da9704815c606109493d8af19999a65",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_warning.png": "e4606e6910d7c48132912eb818e3a55f",
"assets/packages/rflutter_alert/assets/images/2.0x/icon_info.png": "612ea65413e042e3df408a8548cefe71",
"assets/packages/rflutter_alert/assets/images/2.0x/close.png": "abaa692ee4fa94f76ad099a7a437bd4f",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_success.png": "1c04416085cc343b99d1544a723c7e62",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_error.png": "15ca57e31f94cadd75d8e2b2098239bd",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_warning.png": "e5f369189faa13e7586459afbe4ffab9",
"assets/packages/rflutter_alert/assets/images/3.0x/icon_info.png": "e68e8527c1eb78949351a6582469fe55",
"assets/packages/rflutter_alert/assets/images/3.0x/close.png": "98d2de9ca72dc92b1c9a2835a7464a8c",
"assets/packages/rflutter_alert/assets/images/icon_error.png": "f2b71a724964b51ac26239413e73f787",
"assets/packages/rflutter_alert/assets/images/icon_warning.png": "ccfc1396d29de3ac730da38a8ab20098",
"assets/packages/rflutter_alert/assets/images/icon_info.png": "3f71f68cae4d420cecbf996f37b0763c",
"assets/packages/rflutter_alert/assets/images/close.png": "13c168d8841fcaba94ee91e8adc3617f",
"assets/shaders/ink_sparkle.frag": "4096b5150bac93c41cbc9b45276bd90f",
"assets/AssetManifest.bin": "216c60dadfc830de14b00967416fe203",
"assets/fonts/MaterialIcons-Regular.otf": "e2cb7ffb8a5968c54e08047ae9c4c238",
"assets/assets/images/img_google.svg": "b6b87d445f611fab3d126b39ce1bf481",
"assets/assets/images/img_unsplash86rvjm9zowy.png": "b7995eb3acaf8357b5fcb34ce8932154",
"assets/assets/images/img_rectangle458.png": "bf467c5fd57d03b3d0ed8f161a6cbac3",
"assets/assets/images/img_reply.svg": "ac21537b4a60d9e040a5eeb3794672c0",
"assets/assets/images/img_rectangle460_87x113.png": "27f000df4134fd027b7f7a24da113d50",
"assets/assets/images/img_4260006585123_66x66.png": "1c693443896221167d9cd298f6d0ff28",
"assets/assets/images/img_call_gray_900.svg": "b234f1880fcc7f9e81be3839c4843385",
"assets/assets/images/img_call_white_a700.svg": "7f491f4279d50af6480890a1c922f697",
"assets/assets/images/img_plus.svg": "4d5192f0738cc7dbad4637ecb871d091",
"assets/assets/images/img_unsplashfepfs43yipe.png": "fd55a9391c7cb98135de32094d0ff62c",
"assets/assets/images/img_iconhospital.svg": "e3c5c43e433a50c5d5ade045d226da31",
"assets/assets/images/img_rectangle460_87x138.png": "ad63bc055d8de3d3fdb43dabd7ed7070",
"assets/assets/images/img_group108.svg": "a6fbb65aa6da087c6bf9e5d0662d8acd",
"assets/assets/images/img_pexelsthirdman5327580.png": "71661a861b82cf6c613ab9b53ac1d31b",
"assets/assets/images/img_location_primary.svg": "4dd19c697f861821edb39ea33dd1c885",
"assets/assets/images/img_healthvitllys.png": "8dd15b87159ad0c1a8c70d4a749ee955",
"assets/assets/images/img_checkmark_teal_400_01.svg": "b6446a9f4c678ca5bf0d59fb6ec7d029",
"assets/assets/images/img_image10.png": "67ffab04f9cc6f25aee406cf33e043e4",
"assets/assets/images/img_lock.svg": "2c3f80ecd589d3b6f14654d33454eb69",
"assets/assets/images/img_iconlyboldmessage.svg": "fc2b46169206fd50db22abe607772f03",
"assets/assets/images/img_healthvitllys_163x163.png": "16888648b6f07eeccbea55609bcaaa65",
"assets/assets/images/img_button.svg": "eeae8e6d6a839c8ce7f6f95f0e26ac01",
"assets/assets/images/img_ellipse27.png": "a731fb8af767e437ed45f4f495abb92d",
"assets/assets/images/img_arrowleft.svg": "5f827d2ef6b0809181067cd7b7840461",
"assets/assets/images/img_search_gray_700_01.svg": "f2d8eb15e5176456e519d056ffb80760",
"assets/assets/images/img_videocamera_gray_900.svg": "4ffb1093186fde8614ba785f4e74b427",
"assets/assets/images/img_component1_white_a700.svg": "690acf661dd9de602aed1443be6ef270",
"assets/assets/images/img_link.svg": "0c36c55608e8f4d45a29ec11a5cb9687",
"assets/assets/images/img_warning.svg": "a2539d70cce3d9291ee9c80d02883d99",
"assets/assets/images/img_call_primary.svg": "fc5e54901b1b1ea98b2766bb724ffbdf",
"assets/assets/images/img_calciumllysin.png": "76fe20cc891f7fc5d6e08d4e9c4e963a",
"assets/assets/images/img_lock_primary.svg": "eaacf965eb2f6247b8c3a4612b5af95a",
"assets/assets/images/img_cart.svg": "141cccfa763af62844cdd1beaf8abd92",
"assets/assets/images/img_settings_white_a700.svg": "2d0a64772e30b86433fdb4d7614d7e6c",
"assets/assets/images/img_35location.png": "69721696c65f6fc58a676b4de77471a8",
"assets/assets/images/img_pexelsthirdman5327656_64x64.png": "5ea55a3566c2794f81d40453f49cfc86",
"assets/assets/images/img_rectangle460.png": "d0a01a27646e263ca107ba3d0aa13d69",
"assets/assets/images/img_pexelscedricf_64x64.png": "5f17bc59f344dacc35d0b1dceed5c04d",
"assets/assets/images/img_ef58faa9a71e47e.png": "595d98c31f506f2d0286f25bcb2c9bb5",
"assets/assets/images/img_pexelsevelinazhu5434019_64x64.png": "df9f732db692ed25a90193e9797275e4",
"assets/assets/images/img_checkmark_blue_gray_300.svg": "f79b1705b47607ebb7a76b31ccf61f57",
"assets/assets/images/img_camera.svg": "d1117df24938dd78252db6a91102fa6f",
"assets/assets/images/img_group141.svg": "cdac9715b3a5717c1525ea879c3bec59",
"assets/assets/images/img_group19.svg": "8e41760d36346f3084c05ad196b171e0",
"assets/assets/images/img_calciumllysin_50x50.png": "02ff5fde16bb18b6d7c544a83e92d0c3",
"assets/assets/images/img_26audiocall.png": "90f07e6a61fec90b0463b88f7e4495a7",
"assets/assets/images/img_7xm6.png": "461e909d0588380d3417a3a9a84ea9db",
"assets/assets/images/img_pexelscedricf.png": "38d7bcf5f9f55ad1c53a75addac98217",
"assets/assets/images/img_checkmark_white_a700.svg": "5fad0de22ff8738ae661e62b8c6b7a3d",
"assets/assets/images/img_location_blue_gray_300.svg": "e3d4d72a2a9e6f06dd2c2a5aef506779",
"assets/assets/images/img_pexelscedricf_115x115.png": "7bc6d2354f59875413ca73513a9fba5f",
"assets/assets/images/img_pexelsthirdman5327656.png": "2df952aa47f709376be8a195c1e80b59",
"assets/assets/images/img_7xm5.png": "7d2afbd0296d799972ef1fd16352cf9e",
"assets/assets/images/img_car_gray_500_01.svg": "de90962e2fdc331154c90099425218a9",
"assets/assets/images/img_pexelsthirdman5327580_111x111.png": "250a3bfb69d40cd2cbf279bb5933d4ea",
"assets/assets/images/img_contractrqe1.png": "fdc7a0019a18a5861bfbe705028ab13e",
"assets/assets/images/user.png": "4cbcc447550bb078fcb97abd3a3cbcc4",
"assets/assets/images/img_7xm1.png": "9b5fb2e7906090a7d34cf1c6c19e51aa",
"assets/assets/images/img_splash_logo.png": "9644e141824378333038d9999f97e847",
"assets/assets/images/img_calendar_gray_500_01.svg": "0ab2002755b248e83fafd446fe2ef27e",
"assets/assets/images/img_checkmark_primary_16x16.svg": "758795cf250ed42c6565f2ba2c305645",
"assets/assets/images/img_settings.svg": "40cb5b1c2976bcbf5136847dda80bf43",
"assets/assets/images/img_7xm2.png": "157f702264c7f13fe4a6c910a94135dd",
"assets/assets/images/img_pexelsevelinazhu5434019_111x111.png": "d35de67a066c6fc0f0c031b15b1cc720",
"assets/assets/images/img_pexelsevelinazhu5434019.png": "fba27f3ab1ab17740385eeb357afe09b",
"assets/assets/images/img_pexelsthirdman5327580_64x64.png": "c5ba37a772547d8034e18a7a1a000bc1",
"assets/assets/images/img_user.svg": "c992bb995dd415361e0420a879cbf87a",
"assets/assets/images/img_videocamera.svg": "04535cad453cda99b1121ece9ea4c8f0",
"assets/assets/images/img_component1.svg": "7783e18aa214ffec8cef207efe11589e",
"assets/assets/images/img_home.svg": "d08071d7dc95766c22f2f225e0424beb",
"assets/assets/images/img_arrowup.svg": "2c664107d241faa72ec1c0f3b4f985d1",
"assets/assets/images/img_calendar_primary.svg": "d04c3a407668eaf3e54b6b97234401bf",
"assets/assets/images/img_cut.svg": "d03ce7416508e65b006fff936d71ecc2",
"assets/assets/images/img_pexelscedricf_1.png": "529daa6a08d4d86d0b2d951297be5432",
"assets/assets/images/img_location_secondarycontainer.svg": "57a044d0f67e7bc6757db5730e7bba52",
"assets/assets/images/img_menu.svg": "dd6b780fd6b16d6271897cd0a229f8b2",
"assets/assets/images/img_vector.svg": "eaefd7114b0abd7881490b35654320c1",
"assets/assets/images/img_bookmark_white_a700.svg": "f233db7f393151f43b5887dd8cb44577",
"assets/assets/images/img_car.svg": "a987a8b7972c861148138fc7755484e6",
"assets/assets/images/img_user_primary.svg": "776341018887e8af4068cf01b0d8071c",
"assets/assets/images/img_clock_primary.svg": "d30514fdfde91e5c446a605cc7e8ddc7",
"assets/assets/images/img_signal.svg": "721fc5028e425eee22fbe97f674b49b1",
"assets/assets/images/img_pexelscedricf_88x88.png": "42d7854d8aea6d03dbaaa4ceeda73152",
"assets/assets/images/img_group19_cyan_300.png": "5a2ba930d22ac302a5eb0b80a3b47c82",
"assets/assets/images/img_iconpsychiatrist.svg": "93a0768e5181d44fa078eaf468828430",
"assets/assets/images/img_group19_gray_500_01.svg": "e2ce4a6b1c530d4d05a99705d14b73a4",
"assets/assets/images/img_link_primary.svg": "9f4a0206c8ee32430261c8d085757ac7",
"assets/assets/images/img_search.svg": "d4aafd637c88b0aa8f21331939a6104e",
"assets/assets/images/img_input.svg": "31ea7f5c2ca5206aa0987e3e248c0b21",
"assets/assets/images/img_iconlungs.svg": "0f88653e54186ec3e2ce20bb48a60e60",
"assets/assets/images/img_checkmark_gray_500_01.svg": "64326908acd01caa3fba4ab9704921e0",
"assets/assets/images/img_user_white_a700.svg": "5b2739f5f39fa68a8dcad541fbaa9aa5",
"assets/assets/images/img_call.svg": "c9b5a8f032034b82c28c0549a949e3d9",
"assets/assets/images/unnamed.png": "8bb711dd78cdd338aa19e260038bb075",
"assets/assets/images/img_group17.svg": "099aa081696d31978f3a613ee8d1faa4",
"assets/assets/images/img_pexelscedricf_111x111.png": "27157a661ce0535427d69a379737855e",
"assets/assets/images/img_favorite.svg": "34a66f7740201f7868284041fe6a09a0",
"assets/assets/images/img_unsplash5tymgag0wro.png": "7ff193b97b0dac5282823ccf7f550412",
"assets/assets/images/img_videocamera_white_a700.svg": "a3aca18d20955bc5c6bd72a98d2aa91f",
"assets/assets/images/img_trash.svg": "725ea866de7af294553b5acffb34b4c5",
"assets/assets/images/img_4260006585123.png": "1c693443896221167d9cd298f6d0ff28",
"assets/assets/images/img_microphone.svg": "e65dd276c041281a2e69a9cc1000a5d9",
"assets/assets/images/img_facebook.svg": "f5b2c864fe350f54d9621372636dd222",
"assets/assets/images/img_location_white_a700.svg": "3f4e9963a6db1fc1c9e6cce07fa3d1b8",
"assets/assets/images/img_checkmark.svg": "3a6b2592237d5e35acc23c6d91f74eaf",
"assets/assets/images/img_icroundlogout.svg": "01aa94466f764a723399904c393506e4",
"assets/assets/images/img_bookmark.svg": "8fb66b4467603ee87f3dfff6af344856",
"assets/assets/images/img_star.svg": "3db77db13e6da1210e5e7c2b665c5832",
"assets/assets/images/img_portraitsucces.png": "30d4a45cdbb25f6f432ae1be0598357e",
"assets/assets/images/img_pexelsevelinazhu5434019_50x50.png": "99ff5502de4ebd6d9a9a33e03356d4db",
"assets/assets/images/doctor-default.png": "ca50e94eec4443d8173fea0d85dc84c0",
"assets/assets/images/img_icondentist.svg": "f891d2862203d024e6c1f0019850036d",
"assets/assets/images/img_trash_gray_500_01.svg": "42b83a8b239c4635947b7ebcb82ae57f",
"assets/assets/images/image_not_found.png": "a88029aaad6e6ea7596096c7c451840b",
"assets/assets/images/img_pexelsanthony.png": "102f8ad58c9f6c576ea5bc8dafb267cf",
"assets/assets/images/img_arrowright.svg": "cd0198ae924cb91156405297a1b44328",
"assets/assets/images/img_calendar_gray_700_01.svg": "b0ba8238d9e96c0d23445bdb85ce067f",
"assets/assets/images/img_location_blue_gray_800.svg": "30c8657bcee683ec43b8a1336abc23e5",
"assets/assets/images/img_clock.svg": "52da03ad5de62bbd1138151632837773",
"assets/assets/images/img_healthvitllys_50x50.png": "d75755276a017e9e207dab689616b777",
"assets/assets/images/img_user_gray_500_01.svg": "e894d320caccea72c927615115b47272",
"assets/assets/images/img_clock_primary_43x43.svg": "0d90b8af6a38e175ac14a416be8330ee",
"assets/assets/images/img_close.png": "d321631f7bf4ab93f7dad6f8488c24ce",
"assets/assets/images/img_location.svg": "ce11a68d3d037cfb8322c762358842d6",
"assets/assets/images/img_profile.png": "f3f12dd3fd6a3a66329c758bab610ba4",
"assets/assets/images/img_image.png": "c13ddefe0c2041698af6ba1202e2b208",
"assets/assets/images/img_apple.svg": "8eba8029e5f817674c8ec4b1e87aad04",
"assets/assets/images/img_calendar.svg": "5edfda1de242a615658e3c6b9eecfa3f",
"assets/assets/images/img_buttonchat.svg": "0b46333630768ab112fe1cbffbceb1f4",
"assets/assets/images/img_cart_primary.svg": "dfc48ae540fd80b463d21591180b3871",
"assets/assets/images/img_arrowdown.svg": "f53b93ffaa97da6908e0c111d932ef01",
"assets/assets/images/img_logo2.svg": "96f9379e8585288cafa04bd885254983",
"assets/assets/images/img_volume.svg": "989f31558bcedbd10bfbcb7792b45770",
"assets/assets/images/img_checkmark_primary.svg": "fc60862dccd63df924a60780b8424e46",
"assets/assets/images/img_search_gray_900.svg": "1e6a20a33578b9bc381bdd1ae9d19ac1",
"assets/assets/fonts/Poppins-Medium.ttf": "bf59c687bc6d3a70204d3944082c5cc0",
"assets/assets/fonts/Poppins-Regular.ttf": "093ee89be9ede30383f39a899c485a82",
"assets/assets/fonts/Poppins-Bold.ttf": "08c20a487911694291bd8c5de41315ad",
"assets/assets/fonts/Poppins-SemiBold.ttf": "6f1520d107205975713ba09df778f93f",
"canvaskit/skwasm.js": "445e9e400085faead4493be2224d95aa",
"canvaskit/skwasm.js.symbols": "9e6ecac08b1bb78316f11908216be515",
"canvaskit/canvaskit.js.symbols": "b6083d7be42b990438e87f4427056af0",
"canvaskit/skwasm.wasm": "0e946a8af73c72e9f52d06bdc45f882c",
"canvaskit/chromium/canvaskit.js.symbols": "44f9ff6fa9e2a679379892adce6bc73a",
"canvaskit/chromium/canvaskit.js": "43787ac5098c648979c27c13c6f804c3",
"canvaskit/chromium/canvaskit.wasm": "42bcad93dde7da49eb71da7d981ac859",
"canvaskit/canvaskit.js": "c86fbd9e7b17accae76e5ad116583dc4",
"canvaskit/canvaskit.wasm": "c4205649277a26f368d2810db24d51d6",
"canvaskit/skwasm.worker.js": "bfb704a6c714a75da9ef320991e88b03"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
